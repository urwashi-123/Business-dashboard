# Business Listings Dashboard

A full-stack dashboard that collects business listing data, stores it in MySQL,
and visualizes it through a React frontend backed by a FastAPI API.

Built as part of the Python Developer Internship technical assignment.

## Tech Stack

- **Frontend:** React.js + Recharts (bar & pie charts), Axios
- **Backend:** FastAPI (Python), SQLAlchemy ORM
- **Database:** MySQL
- **Scraping:** Python (requests + BeautifulSoup)

## Project Structure

```
business-dashboard/
├── backend/
│   ├── app/
│   │   ├── main.py            # FastAPI entry point
│   │   ├── database.py        # DB connection/session setup
│   │   ├── models.py          # SQLAlchemy model (listing_master)
│   │   ├── schemas.py         # Pydantic request/response schemas
│   │   └── routers/
│   │       ├── listings.py    # bulk insert + fetch listings
│   │       └── dashboard.py   # city/category/source aggregation APIs
│   ├── scraper/
│   │   ├── scrape.py          # data collection script
│   │   ├── load_to_db.py      # pushes listings.json into the DB via API
│   │   └── listings.json      # generated dataset (550 records)
│   ├── requirements.txt
│   └── .env.example
├── frontend/
│   ├── src/
│   │   ├── App.js
│   │   ├── api.js             # API calls to the backend
│   │   └── components/        # CityChart, CategoryChart, SourceChart, SummaryCards
│   └── package.json
├── database/
│   └── listing_master_dump.sql
└── README.md
```

## Setup Instructions

### 1. Database (MySQL)

Make sure MySQL is installed and running, then either let the backend
auto-create the table, or load the provided dump directly:

```bash
mysql -u root -p < database/listing_master_dump.sql
```

This creates the `business_dashboard` database, the `listing_master` table,
and loads it with 550 sample listings.

### 2. Backend (FastAPI)

```bash
cd backend
python -m venv venv
source venv/bin/activate        # Windows: venv\Scripts\activate
pip install -r requirements.txt

cp .env.example .env
# edit .env with your MySQL username/password

uvicorn app.main:app --reload
```

The API will be available at `http://127.0.0.1:8000`.
Interactive docs (Swagger UI): `http://127.0.0.1:8000/docs`

**Endpoints:**
| Method | Endpoint                        | Description                     |
|--------|----------------------------------|----------------------------------|
| POST   | `/api/listings/bulk`            | Bulk insert listings             |
| GET    | `/api/listings`                 | Fetch listings (with filters)    |
| GET    | `/api/dashboard/city-counts`    | City-wise counts                 |
| GET    | `/api/dashboard/category-counts`| Category-wise counts             |
| GET    | `/api/dashboard/source-counts`  | Source-wise counts                |
| GET    | `/api/dashboard/summary`        | Overview totals                  |

### 3. Load data (if not using the SQL dump directly)

```bash
cd backend/scraper
python scrape.py          # regenerates/refreshes listings.json
python load_to_db.py      # pushes it into the DB via the bulk API
```

### 4. Frontend (React)

```bash
cd frontend
npm install
cp .env.example .env      # points the app at the backend URL
npm start
```

Opens at `http://localhost:3000` and displays the dashboard with
city-wise, category-wise, and source-wise charts.

## Scraping Approach

Large directory platforms (Google Maps, JustDial, Sulekha) actively block
automated scraping through JavaScript rendering, CAPTCHAs and aggressive
rate limiting. `scrape.py` first attempts a real scrape against a
scraping-friendly public directory using `requests` + `BeautifulSoup`
(with request delays to stay polite). Since reliably pulling 500+ records
from a bot-protected platform isn't realistic within the assignment
timeline, the script tops up the dataset with programmatically generated,
realistic listings (varied business names, categories, cities and phone
numbers) to reach 550 total records — this fallback is explicitly allowed
by the assignment brief. The generation logic and real-scrape logic live
side by side in the same script, so swapping in a different target site
only means updating the CSS selectors in `scrape_real_listings()`.

## Challenges Faced

- **Anti-scraping measures:** Most major directories require a headless
  browser (Selenium/Playwright) and still risk IP bans; given the 3-5 day
  timeline, I designed the scraper to be source-agnostic and supplemented
  it with generated data rather than over-investing in bypassing bot
  protection.
- **Aggregation performance:** Used indexed columns (`city`, `category`,
  `source`) and `GROUP BY` queries at the DB level instead of pulling all
  rows and aggregating in Python, so the dashboard stays fast as data grows.
- **Bulk inserts:** Used `bulk_save_objects` in SQLAlchemy instead of
  inserting row-by-row, which meant switching from per-row API calls to a
  single batched `/api/listings/bulk` endpoint.

## Notes

- CORS is open (`allow_origins=["*"]`) for local development convenience;
  in production this should be restricted to the actual frontend origin.
- The `.env` file is git-ignored; use `.env.example` as a template.
