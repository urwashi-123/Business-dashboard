import React from "react";

export default function SummaryCards({ summary }) {
  const items = [
    { label: "Total Listings", value: summary.total_listings },
    { label: "Cities Covered", value: summary.total_cities },
    { label: "Categories", value: summary.total_categories },
  ];

  return (
    <div className="summary-cards">
      {items.map((item) => (
        <div className="summary-card" key={item.label}>
          <span className="summary-card__value">{item.value ?? "-"}</span>
          <span className="summary-card__label">{item.label}</span>
        </div>
      ))}
    </div>
  );
}
