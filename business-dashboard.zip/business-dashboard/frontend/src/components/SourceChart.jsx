import React from "react";
import {
  BarChart,
  Bar,
  XAxis,
  YAxis,
  CartesianGrid,
  Tooltip,
  ResponsiveContainer,
  Cell,
} from "recharts";

const COLORS = ["#14b8a6", "#0ea5e9", "#6366f1", "#22c55e", "#f97316"];

export default function SourceChart({ data }) {
  return (
    <div className="chart-card">
      <div className="chart-card__header">
        <h3>Source-wise Business Count</h3>
        <span className="chart-card__subtitle">Where each listing was collected from</span>
      </div>
      <ResponsiveContainer width="100%" height={300}>
        <BarChart data={data} layout="vertical" margin={{ top: 10, right: 30, left: 10, bottom: 10 }}>
          <CartesianGrid strokeDasharray="3 3" horizontal={false} stroke="#e5e7eb" />
          <XAxis type="number" allowDecimals={false} tick={{ fontSize: 12, fill: "#4b5563" }} />
          <YAxis
            dataKey="label"
            type="category"
            width={90}
            tick={{ fontSize: 12, fill: "#4b5563" }}
          />
          <Tooltip
            contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb" }}
            cursor={{ fill: "#f3f4f6" }}
          />
          <Bar dataKey="count" radius={[0, 6, 6, 0]} barSize={22}>
            {data.map((_, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Bar>
        </BarChart>
      </ResponsiveContainer>
    </div>
  );
}
