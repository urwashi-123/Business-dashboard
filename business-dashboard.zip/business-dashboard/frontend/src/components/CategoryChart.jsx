import React from "react";
import {
  PieChart,
  Pie,
  Cell,
  Tooltip,
  Legend,
  ResponsiveContainer,
} from "recharts";

const COLORS = [
  "#2563eb", "#0ea5e9", "#14b8a6", "#22c55e", "#eab308",
  "#f97316", "#ef4444", "#ec4899", "#a855f7", "#6366f1",
];

export default function CategoryChart({ data }) {
  // Keep the pie readable: show top 8 categories, group the rest as "Others"
  const sorted = [...data].sort((a, b) => b.count - a.count);
  const top = sorted.slice(0, 8);
  const rest = sorted.slice(8);
  const restTotal = rest.reduce((sum, item) => sum + item.count, 0);
  const chartData = restTotal > 0 ? [...top, { label: "Others", count: restTotal }] : top;

  return (
    <div className="chart-card">
      <div className="chart-card__header">
        <h3>Category-wise Business Count</h3>
        <span className="chart-card__subtitle">Distribution across business categories</span>
      </div>
      <ResponsiveContainer width="100%" height={340}>
        <PieChart>
          <Pie
            data={chartData}
            dataKey="count"
            nameKey="label"
            cx="50%"
            cy="50%"
            outerRadius={110}
            innerRadius={55}
            paddingAngle={2}
          >
            {chartData.map((_, index) => (
              <Cell key={index} fill={COLORS[index % COLORS.length]} />
            ))}
          </Pie>
          <Tooltip contentStyle={{ borderRadius: 8, border: "1px solid #e5e7eb" }} />
          <Legend
            layout="vertical"
            align="right"
            verticalAlign="middle"
            wrapperStyle={{ fontSize: 12, color: "#4b5563" }}
          />
        </PieChart>
      </ResponsiveContainer>
    </div>
  );
}
