import React, { useEffect, useState } from "react";
import { getCityCounts, getCategoryCounts, getSourceCounts, getSummary } from "./api";
import CityChart from "./components/CityChart";
import CategoryChart from "./components/CategoryChart";
import SourceChart from "./components/SourceChart";
import SummaryCards from "./components/SummaryCards";
import "./App.css";

export default function App() {
  const [cityData, setCityData] = useState([]);
  const [categoryData, setCategoryData] = useState([]);
  const [sourceData, setSourceData] = useState([]);
  const [summary, setSummary] = useState({});
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    async function fetchAll() {
      try {
        const [cityRes, categoryRes, sourceRes, summaryRes] = await Promise.all([
          getCityCounts(),
          getCategoryCounts(),
          getSourceCounts(),
          getSummary(),
        ]);
        setCityData(cityRes.data);
        setCategoryData(categoryRes.data);
        setSourceData(sourceRes.data);
        setSummary(summaryRes.data);
      } catch (err) {
        console.error("Failed to load dashboard data:", err);
        setError(
          "Could not reach the API. Make sure the FastAPI backend is running on http://127.0.0.1:8000"
        );
      } finally {
        setLoading(false);
      }
    }
    fetchAll();
  }, []);

  return (
    <div className="app">
      <header className="app__header">
        <div>
          <h1>Business Listings Dashboard</h1>
          <p>Aggregated view of scraped business listings by city, category and source</p>
        </div>
      </header>

      {loading && <div className="status status--loading">Loading dashboard data...</div>}

      {error && <div className="status status--error">{error}</div>}

      {!loading && !error && (
        <main className="app__content">
          <SummaryCards summary={summary} />

          <div className="chart-grid">
            <CityChart data={cityData.slice(0, 10)} />
            <CategoryChart data={categoryData} />
          </div>

          <div className="chart-grid chart-grid--single">
            <SourceChart data={sourceData} />
          </div>
        </main>
      )}

      <footer className="app__footer">
        Business Listings Dashboard &middot; FastAPI + MySQL + React
      </footer>
    </div>
  );
}
