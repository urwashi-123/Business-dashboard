import axios from "axios";

// Base URL of the FastAPI backend. Change this if the backend runs on a
// different host/port (e.g. when deployed).
const API_BASE_URL = process.env.REACT_APP_API_URL || "http://127.0.0.1:8000";

const api = axios.create({
  baseURL: API_BASE_URL,
});

export const getCityCounts = () => api.get("/api/dashboard/city-counts");
export const getCategoryCounts = () => api.get("/api/dashboard/category-counts");
export const getSourceCounts = () => api.get("/api/dashboard/source-counts");
export const getSummary = () => api.get("/api/dashboard/summary");

export default api;
