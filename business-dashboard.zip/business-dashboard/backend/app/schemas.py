"""
schemas.py
----------
Pydantic models used for request validation and response serialization.
Kept separate from the SQLAlchemy models so the API contract doesn't
leak internal DB details.
"""

from typing import Optional, List
from datetime import datetime
from pydantic import BaseModel


class ListingBase(BaseModel):
    business_name: str
    category: Optional[str] = None
    city: Optional[str] = None
    address: Optional[str] = None
    phone: Optional[str] = None
    source: Optional[str] = None


class ListingCreate(ListingBase):
    pass


class ListingBulkCreate(BaseModel):
    listings: List[ListingCreate]


class ListingOut(ListingBase):
    id: int
    created_at: Optional[datetime] = None

    class Config:
        from_attributes = True


class CountItem(BaseModel):
    label: str
    count: int


class BulkInsertResponse(BaseModel):
    inserted: int
    message: str
