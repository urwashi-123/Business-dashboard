"""
main.py
-------
FastAPI application entry point. Wires up CORS (so the React dev server
can call the API), creates tables on startup if they don't exist yet,
and mounts the listings/dashboard routers.

Run with: uvicorn app.main:app --reload
"""

from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

from .database import Base, engine
from .routers import listings, dashboard

app = FastAPI(
    title="Business Listings Dashboard API",
    description="APIs for storing scraped business listings and serving dashboard aggregates",
    version="1.0.0",
)

# Allow the React dev server (and any origin during local dev) to call the API
app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)


@app.on_event("startup")
def on_startup():
    # Creates listing_master table automatically if it doesn't already exist
    Base.metadata.create_all(bind=engine)


app.include_router(listings.router)
app.include_router(dashboard.router)


@app.get("/")
def root():
    return {"status": "ok", "message": "Business Listings Dashboard API is running"}
