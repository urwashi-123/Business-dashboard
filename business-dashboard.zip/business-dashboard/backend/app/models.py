"""
models.py
---------
SQLAlchemy ORM model matching the listing_master table described in the
assignment. Indexes are added on city, category and source since the
dashboard endpoints group/filter heavily on these columns.
"""

from sqlalchemy import Column, Integer, String, TIMESTAMP, func
from .database import Base


class ListingMaster(Base):
    __tablename__ = "listing_master"

    id = Column(Integer, primary_key=True, index=True, autoincrement=True)
    business_name = Column(String(255), nullable=False)
    category = Column(String(100), index=True)
    city = Column(String(100), index=True)
    address = Column(String(255))
    phone = Column(String(20))
    source = Column(String(50), index=True)
    created_at = Column(TIMESTAMP, server_default=func.now())
