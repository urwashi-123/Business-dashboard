"""
routers/dashboard.py
---------------------
Aggregation endpoints that power the React dashboard's charts.
Each one runs a simple GROUP BY + COUNT query against listing_master.
"""

from fastapi import APIRouter, Depends
from sqlalchemy import func
from sqlalchemy.orm import Session
from typing import List

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/api/dashboard", tags=["Dashboard"])


@router.get("/city-counts", response_model=List[schemas.CountItem])
def city_counts(db: Session = Depends(get_db)):
    rows = (
        db.query(models.ListingMaster.city, func.count(models.ListingMaster.id))
        .group_by(models.ListingMaster.city)
        .order_by(func.count(models.ListingMaster.id).desc())
        .all()
    )
    return [{"label": city or "Unknown", "count": count} for city, count in rows]


@router.get("/category-counts", response_model=List[schemas.CountItem])
def category_counts(db: Session = Depends(get_db)):
    rows = (
        db.query(models.ListingMaster.category, func.count(models.ListingMaster.id))
        .group_by(models.ListingMaster.category)
        .order_by(func.count(models.ListingMaster.id).desc())
        .all()
    )
    return [{"label": category or "Unknown", "count": count} for category, count in rows]


@router.get("/source-counts", response_model=List[schemas.CountItem])
def source_counts(db: Session = Depends(get_db)):
    rows = (
        db.query(models.ListingMaster.source, func.count(models.ListingMaster.id))
        .group_by(models.ListingMaster.source)
        .order_by(func.count(models.ListingMaster.id).desc())
        .all()
    )
    return [{"label": source or "Unknown", "count": count} for source, count in rows]


@router.get("/summary")
def summary(db: Session = Depends(get_db)):
    """Quick overview numbers shown at the top of the dashboard."""
    total = db.query(func.count(models.ListingMaster.id)).scalar()
    total_cities = db.query(func.count(func.distinct(models.ListingMaster.city))).scalar()
    total_categories = db.query(func.count(func.distinct(models.ListingMaster.category))).scalar()
    return {
        "total_listings": total,
        "total_cities": total_cities,
        "total_categories": total_categories,
    }
