"""
routers/listings.py
--------------------
Endpoints for inserting and retrieving raw listing records.
"""

from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from typing import List, Optional

from .. import models, schemas
from ..database import get_db

router = APIRouter(prefix="/api/listings", tags=["Listings"])


@router.post("/bulk", response_model=schemas.BulkInsertResponse)
def bulk_insert_listings(payload: schemas.ListingBulkCreate, db: Session = Depends(get_db)):
    """
    Bulk inserts scraped listings into listing_master.
    Used by the scraper's load_to_db.py script to push listings.json
    into the database in one call instead of one request per row.
    """
    if not payload.listings:
        raise HTTPException(status_code=400, detail="No listings provided")

    objects = [
        models.ListingMaster(
            business_name=item.business_name,
            category=item.category,
            city=item.city,
            address=item.address,
            phone=item.phone,
            source=item.source,
        )
        for item in payload.listings
    ]

    db.bulk_save_objects(objects)
    db.commit()

    return schemas.BulkInsertResponse(
        inserted=len(objects),
        message=f"Successfully inserted {len(objects)} listings"
    )


@router.get("", response_model=List[schemas.ListingOut])
def get_listings(
    city: Optional[str] = None,
    category: Optional[str] = None,
    source: Optional[str] = None,
    limit: int = 100,
    offset: int = 0,
    db: Session = Depends(get_db),
):
    """Fetch listings with optional filters, used for a details/table view."""
    query = db.query(models.ListingMaster)

    if city:
        query = query.filter(models.ListingMaster.city == city)
    if category:
        query = query.filter(models.ListingMaster.category == category)
    if source:
        query = query.filter(models.ListingMaster.source == source)

    return query.offset(offset).limit(limit).all()
