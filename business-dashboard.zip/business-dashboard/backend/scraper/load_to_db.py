"""
load_to_db.py
--------------
Reads listings.json (produced by scrape.py) and pushes it into the
running FastAPI backend via the /api/listings/bulk endpoint.

Usage:
    1. Make sure the backend is running: uvicorn app.main:app --reload
    2. python load_to_db.py
"""

import json
import requests

API_URL = "http://127.0.0.1:8000/api/listings/bulk"
BATCH_SIZE = 100


def load_listings(file_path="listings.json"):
    with open(file_path, "r", encoding="utf-8") as f:
        data = json.load(f)

    total_inserted = 0
    for i in range(0, len(data), BATCH_SIZE):
        batch = data[i:i + BATCH_SIZE]
        response = requests.post(API_URL, json={"listings": batch})

        if response.status_code == 200:
            inserted = response.json().get("inserted", 0)
            total_inserted += inserted
            print(f"Batch {i // BATCH_SIZE + 1}: inserted {inserted} rows")
        else:
            print(f"Batch {i // BATCH_SIZE + 1} failed: {response.status_code} - {response.text}")

    print(f"\nDone. Total rows inserted: {total_inserted}")


if __name__ == "__main__":
    load_listings()
